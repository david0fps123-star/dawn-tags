Rank badges for Oraxen, made with the Rank Designer on bestmcserverlist.net

1. Copy the folders "glyphs" and "pack" into plugins/Oraxen/ (they merge with the existing ones).
2. Run /oraxen reload all in the console and wait until the resource pack is rebuilt.
3. Put the badge in front of names, for example with LuckPerms:

lp group dev meta setprefix 270 "%oraxen_dev% "
lp group dragao_sargento meta setprefix 260 "%oraxen_dragao_sargento% "
lp group admin meta setprefix 250 "%oraxen_admin% "
lp group mod meta setprefix 240 "%oraxen_mod% "
lp group helper meta setprefix 230 "%oraxen_helper% "
lp group builder meta setprefix 220 "%oraxen_builder% "
lp group vip meta setprefix 210 "%oraxen_vip% "
lp group vipplus meta setprefix 200 "%oraxen_vipplus% "
lp group legend meta setprefix 190 "%oraxen_legend% "
lp group prime meta setprefix 180 "%oraxen_prime% "
lp group lite meta setprefix 170 "%oraxen_lite% "
lp group member meta setprefix 160 "%oraxen_member% "
lp group lbgt meta setprefix 150 "%oraxen_lbgt% "
lp group mineiro meta setprefix 140 "%oraxen_mineiro% "
lp group nordetino meta setprefix 130 "%oraxen_nordetino% "
lp group sp meta setprefix 120 "%oraxen_sp% "
lp group rdw meta setprefix 110 "%oraxen_rdw% "
lp group dono meta setprefix 100 "%oraxen_dono% "
lp group owner meta setprefix 90 "%oraxen_owner% "
lp group drgt meta setprefix 80 "%oraxen_drgt% "
lp group ajudante meta setprefix 70 "%oraxen_ajudante% "
lp group helper_2 meta setprefix 60 "%oraxen_helper_2% "
lp group x9 meta setprefix 50 "%oraxen_x9% "
lp group media meta setprefix 40 "%oraxen_media% "
lp group streamer meta setprefix 30 "%oraxen_streamer% "
lp group mvp meta setprefix 20 "%oraxen_mvp% "
lp group mvpplus meta setprefix 10 "%oraxen_mvpplus% "

%oraxen_<name>% is the Oraxen placeholder. Your chat and tab plugins need PlaceholderAPI.
The permission lines in glyphs/ranks.yml only decide who may use the badge as a chat emoji.
Badges are 8 px tall: height 8 and ascent 7 keep one image pixel = one font pixel.
